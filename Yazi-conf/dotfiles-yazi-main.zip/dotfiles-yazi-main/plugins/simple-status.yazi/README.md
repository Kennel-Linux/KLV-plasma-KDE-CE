# simple-status.yazi

This is a Yazi plugin for a simplified status line style.

## Dependencies

This plugin only works with Yazi 0.3.0 or later.

## Installation

Install the plugin:

```
ya pack -a Ape/simple-status
```

Create `~/.config/yazi/init.lua` and add:

```
require("simple-status"):setup()
```
